# 2DCCA
A reimplementation of Two-Dimensional Canonical Correlation Analysis (2DCCA) using Numpy (Python 3).
