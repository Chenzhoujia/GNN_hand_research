import numpy as np


def TCCA(X, Y, dim, iters = 10):
    """
    A reimplementation of Two-Dimensional Canonical Correlation Analysis
    by Zhao Zhang, Oct. 2017  (www.zhaozhang.xyz)

    :param
            X: a N * x_height * x_width tensor (N is the sample size)
            Y: a N * y_height * y_width tensor
            dim: the dimension of the final feature matrix is dim*dim
            iters: iterative number
    :return
            Lx, Rx: transformation matrices for view 1
            Ly, Ry: transformation matrices for view 2
            Mx: the mean for view 1
            My: the mean for view 2
    """

    # Get dimension information of inputted samples. N is the number of samples.
    N, x_height, x_width = X.shape
    _, y_height, y_width = Y.shape

    # Remove mean
    Mx = np.mean(X, axis=0)
    My = np.mean(Y, axis=0)
    X -= Mx
    Y -= My
    # Initialize right projection matrices
    Rx = np.random.randn(x_width, dim)
    Ry = np.random.randn(y_width, dim)

    for i in range(iters):
        [Lx, Ly, _ ] = update_L(X, Y, dim, Rx, Ry)
        [Rx, Ry, _ ] = update_R(X, Y, dim, Lx, Ly)

    return Rx, Ry, Lx, Ly, Mx, My


def update_L(X, Y, dim, Rx, Ry):

    N, x_height, _ = X.shape
    _, y_height, _ = Y.shape

    # Compute the auto covariance matrices
    s = np.zeros([x_height, y_height])
    for i in range(N):
        s += np.dot(X[i, :, :], np.dot(Rx, Ry.T)).dot(Y[i, :, :].T)
    Sxy = (1.0 / N) * s

    s = np.zeros([x_height, x_height])
    for i in range(N):
        s += np.dot(X[i, :, :], np.dot(Rx, Rx.T)).dot(X[i, :, :].T)
    Sxx = (1.0 / N) * s

    s = np.zeros([y_height, y_height])
    for i in range(N):
        s += np.dot(Y[i, :, :], np.dot(Ry, Ry.T)).dot(Y[i, :, :].T)
    Syy = (1.0 / N) * s

    # For numerical stability and derive the inverse matrices
    Dx, Vx = np.linalg.eigh((Sxx + Sxx.T) / 2)
    Dy, Vy = np.linalg.eigh((Syy + Syy.T) / 2)
    idx1 = np.where(Dx > 1e-12)[0]
    Dx = Dx[idx1]
    Vx = Vx[:, idx1]
    idx2 = np.where(Dy > 1e-12)[0]
    Dy = Dy[idx2]
    Vy = Vy[:, idx2]

    Sxx_inv = Vx.dot(np.diag(Dx ** -0.5)).dot(Vx.T)
    Syy_inv = Vy.dot(np.diag(Dy ** -0.5)).dot(Vy.T)

    # Singular value decomposition
    T = Sxx_inv.dot(Sxy).dot(Syy_inv)
    U, D, V = np.linalg.svd(T)
    V = V.T
    Lx = np.dot(Sxx_inv, U[:, 0:dim])
    Ly = np.dot(Syy_inv, V[:, 0:dim])
    D = D[0:dim]
    corr = sum(D)

    return Lx, Ly, corr


def update_R(X, Y, dim, Lx, Ly):
    N, _, x_width = X.shape
    _, _, y_width = Y.shape

    # Compute the auto covariance matrices
    s = np.zeros([x_width, y_width])
    for i in range(N):
        s += np.dot(X[i, :, :].T, np.dot(Lx, Ly.T)).dot(Y[i, :, :])
    Kxy = (1.0 / N) * s

    s = np.zeros([x_width, x_width])
    for i in range(N):
        s += np.dot(X[i, :, :].T, np.dot(Lx, Lx.T)).dot(X[i, :, :])
    Kxx = (1.0 / N) * s

    s = np.zeros([y_width, y_width])
    for i in range(N):
        s += np.dot(Y[i, :, :].T, np.dot(Ly, Ly.T)).dot(Y[i, :, :])
    Kyy = (1.0 / N) * s

    # For numerical stability.
    Dx, Vx = np.linalg.eigh((Kxx + Kxx.T) / 2)
    Dy, Vy = np.linalg.eigh((Kyy + Kyy.T) / 2)
    idx1 = np.where(Dx > 1e-12)[0]
    Dx = Dx[idx1]
    Vx = Vx[:, idx1]
    idx2 = np.where(Dy > 1e-12)[0]
    Dy = Dy[idx2]
    Vy = Vy[:, idx2]

    Kxx_inv = Vx.dot(np.diag(Dx ** -0.5)).dot(Vx.T)
    Kyy_inv = Vy.dot(np.diag(Dy ** -0.5)).dot(Vy.T)

    # Singular value decomposition
    T = Kxx_inv.dot(Kxy).dot(Kyy_inv)
    U, D, V = np.linalg.svd(T)
    V = V.T
    Rx = np.dot(Kxx_inv, U[:, 0:dim])
    Ry = np.dot(Kyy_inv, V[:, 0:dim])
    D = D[0:dim]
    corr = sum(D)

    return Rx, Ry, corr

